function ocultar({
            alert("se Oculta");
      }


      function mostrar({
            alert("se muestra");
      })